
package ch01;

public class Salam3 {
    public static void main(String[] args) {
        //Baris ini tidak dicompile
        System.out.println("1 Baris berhasil dicompile !");
    }
}
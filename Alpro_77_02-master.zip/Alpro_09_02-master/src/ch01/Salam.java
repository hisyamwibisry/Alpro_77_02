
package ch01;

public class Salam {
    public static void main(String[] args) {
        System.out.println("Salam Java !");
    }
}
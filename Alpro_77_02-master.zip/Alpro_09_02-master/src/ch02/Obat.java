
package ch02;

import java.util.Date;

public class Obat {
    String barcode;
    String nama;
    Date tanggalKedaluarsa;
    String harga;
    
    public String getBarcode() {
        return nama;
    }
    public Date getTanggalKedaluarsa() {
        return tanggalKedaluarsa;
    }
    
    public String getHarga() {
        return harga;
    }
}
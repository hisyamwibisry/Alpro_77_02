
package ch02;

public class Lingkaran {
    double jarijari;
    double luas() {
        return Math.PI * jarijari * jarijari;
    }
}

package ch02;

public class Trapesium {
    double alasBawah, alasAtas, tinggi;
    double luas() {
        return tinggi * (alasAtas + alasBawah) / 2;
    }
}
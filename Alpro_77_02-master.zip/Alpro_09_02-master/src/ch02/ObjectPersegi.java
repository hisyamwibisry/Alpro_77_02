
package ch02;

public class ObjectPersegi {
    public static void main(String[] args) {
        Persegi x = new Persegi();
        x.sisi = 16;
        System.out.println(" Luas Persegi = " + x.luas());
    }
}
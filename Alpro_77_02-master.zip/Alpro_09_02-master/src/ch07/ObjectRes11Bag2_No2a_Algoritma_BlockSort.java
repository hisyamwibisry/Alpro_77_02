
package ch07;

public class ObjectRes11Bag2_No2a_Algoritma_BlockSort {
    public static void main(String[] args) {
        Res11Bag2_No2a_Algoritma_BlockSort bsort = new Res11Bag2_No2a_Algoritma_BlockSort ();
        System.out.println("Algoritma Block Sort ");
        System.out.println();
        bsort.cetak();
    }
}

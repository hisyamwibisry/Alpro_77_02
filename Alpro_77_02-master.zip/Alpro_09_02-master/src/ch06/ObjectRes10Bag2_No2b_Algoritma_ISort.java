
package ch06;

public class ObjectRes10Bag2_No2b_Algoritma_ISort {
    public static void main(String[] args) {
        int aar[] = {82, 12, 41, 38, 19, 26, 9, 48, 20, 55, 8, 32, 3};
        
        Res10Bag2_No2b_Algoritma_ISort sort = new Res10Bag2_No2b_Algoritma_ISort();
        sort.printArray(aar);
    }
}

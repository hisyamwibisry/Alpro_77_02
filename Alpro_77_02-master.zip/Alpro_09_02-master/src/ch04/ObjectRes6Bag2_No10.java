
package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No10 {
    public static void main(String[] args) {
        Res6Bag2_No10 matriks = new Res6Bag2_No10();
        System.out.println();
        System.out.println(" menampilkan selisih angka genap dengan selisih angka genap setelahnya ");
        System.out.println();
        matriks.cetak();
    }
}

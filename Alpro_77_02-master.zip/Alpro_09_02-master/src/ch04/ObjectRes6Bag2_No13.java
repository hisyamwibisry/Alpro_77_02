
package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No13 {
    public static void main(String[] args) {
        Res6Bag2_No13 matriks = new Res6Bag2_No13();
        System.out.println();
        System.out.println("Menampilkan jumlah selisih pada data aray yang ada pada poin (i) atau 9 ");
        System.out.println();
        matriks.cetak();
    }
}

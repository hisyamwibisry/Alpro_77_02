
package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No12 {
    public static void main(String[] args) {
        Res6Bag2_No12 matriks = new Res6Bag2_No12();
        System.out.println();
        System.out.println("Menampilkan angka dan menjumlahkan setelahnya ");
        System.out.println();
        matriks.cetak();
    }
}


package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No9 {
    public static void main(String[] args) {
        Res6Bag2_No9 matriks = new Res6Bag2_No9 ();
        System.out.println();
        System.out.println("menampilkan selisih angka pada data aray dan selisih setelahnya ");
        System.out.println();
        matriks.cetak();
    }
}

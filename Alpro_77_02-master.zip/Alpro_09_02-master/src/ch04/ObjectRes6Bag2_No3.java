
package ch04;

public class ObjectRes6Bag2_No3 {
    public static void main(String[] args) {
        Res6Bag2_No3 matrik = new Res6Bag2_No3 ();
        System.out.println();
        System.out.println("Menampilkan arai dengan angka ganjil = ");
        System.out.println();
        matrik.cetak();
    }
}
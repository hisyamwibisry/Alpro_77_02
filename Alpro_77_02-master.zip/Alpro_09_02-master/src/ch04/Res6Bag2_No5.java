
package ch04;

public class Res6Bag2_No5 {
   int [] aray = {82, 12, 41, 38, 19, 26, 9, 48, 20, 55, 8, 32, 3};
   int [] angka = {2, 12, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 32, 42, 52, 62, 72, 82, 92, 102};
   
   public void cetak(){
       for(int i = 0; i < aray.length; i++){
           System.out.println(aray [i]);
       }
   }
}

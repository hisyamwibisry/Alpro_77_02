
package ch04;

public class ObjectRes6Bag2_No1 {
    public static void main(String[] args){
        Res6Bag2_No1 matriks = new Res6Bag2_No1();
        System.out.println();
        matriks.cetak();
        System.out.println();
        
    }
}

package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No7 {
    public static void main(String[] args) {
        Res6Bag2_No7 matriks = new Res6Bag2_No7();
        
        System.out.println(" menampilkan data aray kelipatan 5 yang sebelumnya kelipatan 5 ");
        matriks.cetak();
    }
}

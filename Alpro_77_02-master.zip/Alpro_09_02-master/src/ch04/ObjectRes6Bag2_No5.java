
package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No5 {
    public static void main(String[] args) {
        Res6Bag2_No5 matriks = new Res6Bag2_No5();
        System.out.println("\n Menampilkan aray dengan index yg memiliki angka 2 : \n");
        matriks.cetak();
    }
}

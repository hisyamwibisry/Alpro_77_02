
package ch04;

public class Res6Bag2_No4 {
    int[] aray = {82, 12, 41, 38, 19, 26, 9, 48, 20, 55, 8, 32, 3};
    
    public void cetak(){
        for(int i = 0; i < aray.length; i++){
            System.out.println(aray [i]+"");
        }
    }
}
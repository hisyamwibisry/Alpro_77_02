
package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No8 {
    public static void main(String[] args) {
        Res6Bag2_No8 matriks = new Res6Bag2_No8();
        System.out.println(" menampilkan jumlah angka dari aray ");
        
        matriks.cetak2();
        matriks.cetak();
        System.out.println("");
    }
}

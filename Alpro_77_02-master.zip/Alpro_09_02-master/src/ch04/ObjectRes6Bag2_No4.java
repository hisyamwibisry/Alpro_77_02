
package ch04;

public class ObjectRes6Bag2_No4 {
    public static void main(String[] args) {
        Res6Bag2_No4 matriks = new Res6Bag2_No4();
        System.out.println("\n Menampilkann aray dari kelipatan 3 = \n ");
        matriks.cetak();
    }
}


package ch04;
import java.util.Scanner;
import java.util.Arrays;

public class ObjectRes6Bag2_No11 {
    public static void main(String[] args) {
        Res6Bag2_No11 matriks = new Res6Bag2_No11();
        System.out.println("menampilkan angka dari aray yang lebih besar setelahnya");
        matriks.cetak();
        System.out.println();
    }
}

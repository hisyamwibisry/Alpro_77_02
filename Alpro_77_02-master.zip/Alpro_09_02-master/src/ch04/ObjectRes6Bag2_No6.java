
package ch04;
import java.util.Scanner;

public class ObjectRes6Bag2_No6 {
    public static void main(String[] args) {
        Res6Bag2_No6 matriks = new Res6Bag2_No6();
        System.out.println();
        System.out.println("Menampilkan data aray dengan angka ganjil yang diapit angka genap ");
        System.out.println("");
        matriks.cetak();
        
    }
}
